#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 14 16:54:04 2019

@author: terry
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('Met430k.csv',delimiter = ',')
keywords = pd.read_csv("MediumItems.csv",delimiter = ',')


methods = keywords.iloc[:82,:]
materials = keywords.iloc[82:,:]

materials=materials[~materials.Medium.isin(methods.Medium)] #removes duplicates

#Setup Classifications List
classes = pd.DataFrame(data['Class_General'].value_counts())
classes.columns=["value"]
classes = classes.drop("Unknown/Other")

#Write to csv for extra cleaning
classes.index[(classes.index).isin(methods.Medium)] #check no dups
classes.index[(classes.index).isin(materials.Medium)] #check no dups

classes.sum()/data.shape[0] #87% have a classification (exc. unknown)
for i in range (1,20):
    print(classes.value[:(10*i)].sum()/data.shape[0])
classes[classes.value >=1000].sum()/data.shape[0] #81% igonring classification with under 1000 items
classes[classes.value >=1000].shape[0]
classesCut=classes[classes.value >=1000]
classesCut.to_csv('Class_freq_final.csv')

dataCut=data[data.Class_General.isin(classesCut.index)]
dataCut.to_csv('MetCore350k.csv')

#MediumMatch adapted for Classes
def classMatch(data, keywords):
    strings=data[["Object ID","Class_General"]].reset_index()
    for i, text in strings["Class_General"].items():
        strings.at[i,"Class_General"]=str(text).lower()
    
    tags=[]
    for classItem in list(keywords.index):
        tags.append(classItem.lower())
    
    
    PD = data[["Object ID"]]
    PD.loc[:,"class"]=[None]*strings["Class_General"].size
    classes=[None]*strings["Class_General"].size
    for tag in tags:
        column=[0]*strings["Class_General"].size
        for i, string in strings["Class_General"].items():
            if tag == string:
                column[i]=1
                classes[i]=tag
        PD.loc[:,tag]=column
    PD.loc[:,"class"]=classes
    return PD

ClassHot=classMatch(data,classesCut)
ClassHot.iloc[:,2:].sum(axis=1).value_counts()
ClassHot.iloc[:,1].isnull().sum(0)
ClassHot.to_csv("encoded_classes.csv")

def mediumMatch(df, keywordslist):
    strings=df[["Object ID","medium"]].reset_index()
    for i, text in strings["medium"].items():
        strings.at[i,"medium"]=str(text).lower()
    
    tags=np.array(list(keywordslist["Medium"]))
    
    PD = df[["Object ID"]]
    PD.loc[:,"medium"]=[None]*strings["medium"].size
    medium=[None]*strings["medium"].size
    for tag in tags:
        column=[0]*strings["medium"].size
        for i, string in strings["medium"].items():
            if tag in string:
                column[i]=1
                if medium[i] is None:
                    medium[i]=tag
        PD.loc[:,tag]=column
        PD.loc[:,"medium"]=medium
    return PD



# =============================================================================
# Computed values separately but on reflection whether the medium column has a method or material is typically a attribute of the data, and hence often they are exclusive e.g. a coin has medium metal, a photo has medium print
# methodsHot=mediumMatch(dataCut,methods)
# materialsHot=mediumMatch(dataCut,materials)
# methodsHot.to_csv("methodsHot.csv")
# materialsHot.to_csv("materialsHot.csv")
# 
# methodsHot.iloc[:,1:].sum(axis=1).value_counts() #200k with no method, 115k with one method, 30k with more
# materialsHot.iloc[:,1:].sum(axis=1).value_counts() #100k with no material, 140k with one material, 105k with more than one material
# UnionHot=methodsHot[(methodsHot.iloc[:,1:].sum(axis=1)>0) & (materialsHot.iloc[:,1:].sum(axis=1)>0)]
# pd.set_option('display.max_columns', 5)
# 
# data[data["Object ID"].isin(methodsHot[methodsHot.iloc[:,1:].sum(axis=1)==0]["Object ID"])][["object_name","medium","classification","Class_General","object_begin_date"]].sample(10)
# data[data["Object ID"].isin(materialsHot[materialsHot.iloc[:,1:].sum(axis=1)==2]["Object ID"])][["object_name","medium","classification","Class_General","object_begin_date"]].sample(10)
# 
# =============================================================================
keywords2 = keywords.drop_duplicates(subset="Medium",keep="first")
keywords2=keywords2.sort_values(by="Frequency",ascending=False)
TotalHot=mediumMatch(dataCut,keywords2)
TotalHot.to_csv("TotalHot.csv")
TotalHot.iloc[:,2:].sum(axis=1).value_counts()
TotalHot.iloc[:,1].isnull().sum()
frequencies=TotalHot.iloc[:,2:].sum()
frequencies=frequencies.sort_values(ascending=False)
columns=frequencies.index.tolist()
columns.insert(0,"medium")
columns.insert(0,"Object ID")
TotalHot=TotalHot.loc[:,columns]

a=[]
for i in range (1,30):
    a.append(sum(TotalHot.iloc[:,2:(10*i)].sum(axis=1)>0)/dataCut.shape[0])
pd.DataFrame(a).to_csv("medium_cutoff_analysis")

sum(TotalHot.iloc[:,2:42].sum(axis=1)>0)/dataCut.shape[0]
TotalHot.iloc[:,2:42].columns

keywordsCut=pd.DataFrame(TotalHot.iloc[:,2:42].columns.tolist())
keywordsCut.columns=["Medium"]
keywordsCut.to_csv("keywords_freq_final.csv")


#Now we rerun the reduced keywordset on the full dataset and then add classification columns
FinalHot=mediumMatch(data,keywordsCut)
FinalHot.iloc[:,2:].sum(axis=1).value_counts()
sum(FinalHot.iloc[:,2:].sum(axis=1)>0)/data.shape[0] #79% of the data has a medium

classesCut.index[(classesCut.index).isin(keywordsCut.Medium)]#check no overlap between classifications and mediums

FinalHot.to_csv("encoded_list.csv")

#This produces the unique mediums, by stopping after first has been found. Tags in descending order so will make category sizes more unequal
def uniqueMatch():
    PD = pd.DataFrame(0,index=range(FinalHot.shape[0]), columns=range(FinalHot.shape[1]))  
    nrows=PD.shape[0]
    ncols=PD.shape[1]
    PD.iloc[:,0:1]=FinalHot.iloc[:,0:1]
    for i in range(nrows):
        for j in range(2,ncols):
                if abs(FinalHot.iat[i,j]-1)<0.001:
                    PD.iat[i,j]=1
                    break
    PD.columns=FinalHot.columns
    return PD

UniqueHot=uniqueMatch()
UniqueHot.iloc[:,2:].sum(axis=1).value_counts()
UniqueHot.iloc[:,1]=FinalHot.iloc[:,1]
UniqueHot.iloc[:,1].isnull().sum()

UniqueHot.to_csv("encoded_unique.csv")







