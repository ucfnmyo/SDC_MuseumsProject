#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 14 16:54:04 2019

@author: terry
"""

import numpy as np
import pandas as pd

data = pd.read_csv('Met430k.csv',delimiter = ',')
classesCut=pd.read_csv('Class_freq_final.csv',delimiter = ',')
keywordsCut=pd.read_csv("keywords_freq_final.csv",delimiter = ',')
classesCut.loc[classesCut.loc[:,"class"].isin(keywordsCut.Medium),"class"]#check no overlap between classifications and mediums
classesCut.loc[:,"class"].isin(keywordsCut.Medium).sum()

#MediumMatch adapted for Classes
def classMatch(data, keywords):
    strings=data[["Object ID","Class_General"]].reset_index()
    for i, text in strings["Class_General"].items():
        strings.at[i,"Class_General"]=str(text).lower()
    
    tags=[]
    for classItem in list(keywords["class"]):
        tags.append(classItem.lower())
    
    
    PD = data[["Object ID"]]
    PD.loc[:,"class"]=["unknown_other"]*strings["Class_General"].size
    classes=["unknown_other"]*strings["Class_General"].size
    for tag in tags:
        column=[0]*strings["Class_General"].size
        for i, string in strings["Class_General"].items():
            if tag == string:
                column[i]=1
                classes[i]=tag
        PD.loc[:,tag]=column
    PD.loc[:,"class"]=classes
    return PD

ClassHot=classMatch(data,classesCut)
ClassHot.iloc[:,2:].sum(axis=1).value_counts()
(ClassHot.iloc[:,1]=="unknown_other").sum()
ClassHot.to_csv("encoded_classes.csv")

def mediumMatch(df, keywordslist):
    strings=df[["Object ID","medium"]].reset_index()
    for i, text in strings["medium"].items():
        strings.at[i,"medium"]=str(text).lower()
    
    tags=np.array(list(keywordslist["Medium"]))
    
    PD = df[["Object ID"]]
    PD.loc[:,"medium"]=["unknown_other"]*strings["medium"].size
    medium=["unknown_other"]*strings["medium"].size
    for tag in tags:
        column=[0]*strings["medium"].size
        for i, string in strings["medium"].items():
            if tag in string:
                column[i]=1
                if medium[i] is "unknown_other":
                    medium[i]=tag
        PD.loc[:,tag]=column
        PD.loc[:,"medium"]=medium
    return PD


#Now we rerun the reduced keywordset on the full dataset and then add classification columns
FinalHot=mediumMatch(data,keywordsCut)
FinalHot.iloc[:,2:].sum(axis=1).value_counts()
(FinalHot.iloc[:,1]=="unknown_other").sum()

sum(FinalHot.iloc[:,2:].sum(axis=1)>0)/data.shape[0] #79% of the data has a medium
FinalHot.to_csv("encoded_list.csv")
FinalHot=pd.read_csv("encoded_list.csv",delimiter=',')
FinalHot =FinalHot.drop("Unnamed: 0",axis=1)

#This produces the unique mediums, by stopping after first has been found. Tags in descending order so will make category sizes more unequal
def uniqueMatch():
    PD = pd.DataFrame(0,index=range(FinalHot.shape[0]), columns=range(FinalHot.shape[1]),dtype=int)  
    nrows=PD.shape[0]
    ncols=PD.shape[1]
    PD.iloc[:,1]=PD.iloc[:,1].to_string()
    PD.iloc[:,0:1]=FinalHot.iloc[:,0:1]
    for i in range(nrows):
        for j in range(2,ncols):
                if abs(FinalHot.iat[i,j]-1)<0.001:
                    PD.iat[i,j]=1
                    break
    PD.columns=FinalHot.columns
    return PD

UniqueHot=uniqueMatch()
UniqueHot.iloc[:,2:].sum(axis=1).value_counts()
UniqueHot.iloc[:,1]=FinalHot.iloc[:,1]
(UniqueHot.iloc[:,1]=="unknown_other").sum()
UniqueHot.iloc[:,0]=FinalHot.iloc[:,0]

UniqueHot.to_csv("encoded_unique.csv")







