# -*- coding: utf-8 -*-
"""
Created on Thu May 16 11:05:05 2019

@author: ucfntli
"""
import pandas as pd

ClusterData1=pd.read_csv("ClusterData1.csv",delimiter = ',')

ClusterData1["medium"].isnull().sum()
ClusterData1Fixed=ClusterData1
ClusterData1Fixed.loc[ClusterData1["medium"].isnull(),"medium"]="unknown/other"
ClusterData1Fixed["medium"].value_counts()
ClusterData1["class"].isnull().sum()
ClusterData1Fixed.loc[ClusterData1["class"].isnull(),"class"]="unknown/other"
ClusterData1Fixed["class"].value_counts()
ClusterData1Fixed.to_csv("ClusterData1.csv")

ClusterData2=pd.read_csv("ClusterData2.csv",delimiter = ',')

ClusterData2Fixed=ClusterData2
ClusterData2Fixed.loc[:,"medium"]=ClusterData1Fixed.loc[:,"medium"]
ClusterData2Fixed.loc[:,"class"]=ClusterData1Fixed.loc[:,"class"]
ClusterData2Fixed["medium"].value_counts()
ClusterData2Fixed["class"].value_counts()
ClusterData2Fixed.to_csv("ClusterData2.csv")
