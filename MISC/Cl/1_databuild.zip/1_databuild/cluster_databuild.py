#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 15 09:46:25 2019

@author: terry
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('Met430k.csv',delimiter = ',')
classesHot =pd.read_csv('encoded_classes.csv',delimiter = ',')
MediumHot =pd.read_csv('encoded_list.csv',delimiter = ',')
UniqueHot =pd.read_csv('encoded_unique.csv',delimiter = ',')
Geocodes = pd.read_csv('geocodes.csv',delimiter = ',')

classesHot=classesHot.drop("Unnamed: 0",axis=1)
MediumHot =MediumHot.drop("Unnamed: 0",axis=1)
UniqueHot =UniqueHot.drop("Unnamed: 0",axis=1)

ClusterData_Base = data[["Object ID","object_begin_date"]]
ClusterData_Base.columns=["Object ID","age"]
ClusterData_Base=ClusterData_Base.merge(Geocodes,how="left",left_on="Object ID",right_on="Object ID")
ClusterData_Base=ClusterData_Base.merge(classesHot,how="left",left_on="Object ID",right_on="Object ID")

ClusterData1=ClusterData_Base.merge(MediumHot,how="left",left_on="Object ID",right_on="Object ID")
ClusterData2=ClusterData_Base.merge(UniqueHot,how="left",left_on="Object ID",right_on="Object ID")

cols_to_order =["Object ID","age","country","class","medium","coordX","coordY"]
new_columns = cols_to_order + (ClusterData1.columns.drop(cols_to_order).to_list())

ClusterData1=ClusterData1[new_columns]
ClusterData2=ClusterData2[new_columns]

ClusterData1.to_csv("CLusterData1.csv")
ClusterData2.to_csv("ClusterData2.csv")